package misc;

import perm.Permutation;

public class HidenValuesMiner implements FeatureMiner {

	@Override
	public int length() {
		return 0;
	}

	@Override
	public double[] mine(Permutation[] permutations) {
		return null;
	}

}
